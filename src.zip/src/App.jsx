
import './App.css';
import Welcome from './Welcome/Welcome';

function App() {
   
let name = "Misha";
    return ( 
      <>

        <Welcome name = {name}/>
      
      </>
      
    );
}
export default App;