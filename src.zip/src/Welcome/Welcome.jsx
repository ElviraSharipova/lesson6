import React from 'react'

export default function Welcome(props) {
  return (
    <div>Welcome, {props.name }</div>
  )
}
